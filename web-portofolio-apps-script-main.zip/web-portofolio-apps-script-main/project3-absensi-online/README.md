# Absensi Online Mahasiswa
Web app absensi online dengan login NIM,
validasi data mahasiswa, dan relasi data master–transaksi.
## Fitur
- Login menggunakan NIM
- Validasi data mahasiswa
- Input absensi (makul & status)
- Join data absensi & mahasiswa
- Tabel absensi realtime
## Tech Stack
- Google Apps Script
- HTML, CSS, JavaScript
- Google Sheets

## Demo
https://script.google.com/macros/s/AKfycbzdjvz_Tx2hn8sXATlDeQJEZwmfJFa7GVSiLiU8w3WcX-if7njprEWY5c5JcjgRy0BN/exec
