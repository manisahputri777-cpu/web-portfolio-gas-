# Web App GAS - Session 1

Demo Web App:
https://script.google.com/macros/s/AKfycbzUHs3tlJXpfZ9LV82lHGGwnp8zZIqgD1RIcz_MBiP5e1NYaDFhhJQf3CCuDOkRdU2b/exec

## Tech Stack
-Google Apps Script
-HTML

## Deskripsi
Web App Pertama menggunakan Google Apps Script
