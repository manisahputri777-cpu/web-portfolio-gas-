# Contact Form App
Web app sederhana untuk menyimpan pesan user ke Google Sheets.
## Features
- Input form
- Auto timestamp
Google Sheets database
## Demo
https://script.google.com/macros/s/AKfycbydAkmFB9tvBq2T4XXYv2ujqrQVM9iJw46viJpw9Wd9E9zVpeqwgS5zO6CHxVQ9OQpr/exec
